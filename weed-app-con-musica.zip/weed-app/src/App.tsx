/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, 
  Play, 
  Pause, 
  Upload, 
  Settings, 
  Download, 
  Sparkles, 
  Lock, 
  Unlock, 
  Music, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  Eye, 
  EyeOff,
  ChevronRight,
  Terminal,
  FileDown
} from 'lucide-react';
import { Particle, ParticleConfig, ColorScheme } from './types';
import { COLOR_PRESETS } from './utils/presets';
import { generateStandaloneHTML } from './utils/htmlGenerator';

export default function App() {
  // Application State
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [decryptionProgress, setDecryptionProgress] = useState(0);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [decryptText, setDecryptText] = useState('MENSAJE_ENCRIPTADO_DE_AMOR');
  
  const [customWords, setCustomWords] = useState('LOVE, YOU');
  const [renderMode, setRenderMode] = useState<'text' | 'dots' | 'hybrid'>('text');
  const [activeColorScheme, setActiveColorScheme] = useState<ColorScheme>(COLOR_PRESETS[0]);
  const [showControlPanel, setShowControlPanel] = useState(true);
  
  // Custom interactive configs
  const [particlesCount, setParticlesCount] = useState(2500);
  const [bpm, setBpm] = useState(65);
  const [particleSize, setParticleSize] = useState(2.5);
  const [repulsionRadius, setRepulsionRadius] = useState(130);
  const [repulsionStrength, setRepulsionStrength] = useState(10);
  const [enableDoubleBeat, setEnableDoubleBeat] = useState(true);
  const [trailStrength, setTrailStrength] = useState(0.12);
 
  // Audio system state
  const [audioSource, setAudioSource] = useState<'synth' | 'mp3' | 'none'>('none');
  const [audioLoading, setAudioLoading] = useState(false);
  const [customMp3Name, setCustomMp3Name] = useState<string>('');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [liveVolume, setLiveVolume] = useState<number>(0);
 
  // Mouse / touch coordinate logs for Elegant Dark UI stream
  const [mouseCoords, setMouseCoords] = useState({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const [mouseState, setMouseState] = useState<'idle' | 'moving' | 'dispersing'>('idle');
 
  // Canvas & Audio refs
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animationFrameId = useRef<number | null>(null);
  const mouseRef = useRef<{ x: number | null; y: number | null; active: boolean }>({ x: null, y: null, active: false });
  
  // Audio Context and Synth properties
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const synthIntervalId = useRef<any>(null);
  const synthStepRef = useRef<number>(0);
  const htmlAudioRef = useRef<HTMLAudioElement | null>(null);
  const audioSourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const frequencyDataRef = useRef<Uint8Array | null>(null);

  // Text scramble loop during pre-entry screen
  useEffect(() => {
    if (isUnlocked) return;
    
    const originalText = "DESCIFRANDO_MENSAJE_CENTRAL_DE_AMOR";
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*()_+{}[]|;:,.<>?/1234567890";
    
    const interval = setInterval(() => {
      if (isDecrypting) {
        // Scramble with progressive resolution
        const progressFract = decryptionProgress / 100;
        const resolvedLength = Math.floor(originalText.length * progressFract);
        
        let display = "";
        for (let i = 0; i < originalText.length; i++) {
          if (i < resolvedLength) {
            display += originalText[i];
          } else {
            display += chars[Math.floor(Math.random() * chars.length)];
          }
        }
        setDecryptText(display);
      } else {
        // Soft constant scramble
        setDecryptText(prev => 
          prev.split('')
            .map((char) => {
              if (Math.random() < 0.15) return chars[Math.floor(Math.random() * chars.length)];
              return char;
            })
            .join('')
        );
      }
    }, 90);

    return () => clearInterval(interval);
  }, [isUnlocked, isDecrypting, decryptionProgress]);

  // Audio Context initialization helper
  const initAudio = () => {
    if (audioCtxRef.current) return;
    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtxClass();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyser.connect(ctx.destination);
      
      audioCtxRef.current = ctx;
      analyserRef.current = analyser;
      frequencyDataRef.current = new Uint8Array(analyser.frequencyBinCount);
    } catch(err) {
      console.error("No se pudo iniciar el decodificador de audio:", err);
    }
  };

  // Play direct MP3 from url and wire up to synthesizer visual analyzer
  const playMp3FromUrl = (url: string, displayName: string = "Música Romántica 🎵") => {
    setAudioLoading(true);
    setCustomMp3Name(displayName);
    stopSynthesizer();
    initAudio();

    if (htmlAudioRef.current) {
      htmlAudioRef.current.pause();
    }

    const audio = new Audio(url);
    audio.crossOrigin = "anonymous";
    audio.loop = true;
    htmlAudioRef.current = audio;

    const onCanPlay = () => {
      setAudioLoading(false);
      setAudioSource('mp3');
      setIsPlayingAudio(true);
      
      const ctx = audioCtxRef.current;
      const analyser = analyserRef.current;
      
      if (ctx && analyser) {
        if (ctx.state === 'suspended') {
          ctx.resume();
        }
        
        try {
          if (audioSourceNodeRef.current) {
            audioSourceNodeRef.current.disconnect();
          }
          const source = ctx.createMediaElementSource(audio);
          audioSourceNodeRef.current = source;
          source.connect(analyser);
        } catch (err) {
          console.warn("Audio node setup fallback:", err);
        }
      }
      
      audio.play().catch(err => {
        console.warn("Autoplay blocked, waiting user gesture...", err);
      });
    };

    audio.addEventListener('canplaythrough', onCanPlay);
    
    audio.addEventListener('error', (err) => {
      console.warn("Error playing MP3:", url, err);
      // Fallback: Si falla el Drive, carga el Nocturne de Chopin
      if (url === 'https://drive.google.com/uc?export=download&id=1L1iyd6LxCVQ1Xyk9T32TxowexpoF7haq') {
        playMp3FromUrl('https://archive.org/download/ChopinNocturneOp9No2/Chopin-NocturneOp9No2.mp3', 'Chopin - Nocturne Op. 9 No. 2 🎹');
      } else {
        setAudioLoading(false);
        startSynthesizer();
      }
    });

    audio.load();
  };

  // Trigger decryption flow with synthetic sci-fi code sound
  const handleDecrypt = () => {
    if (isDecrypting) return;
    setIsDecrypting(true);
    initAudio();
    playSfxTone(440, 0.05); // immediate unlock beep

    let current = 0;
    const interval = setInterval(() => {
      current += 2;
      setDecryptionProgress(current);

      // Play soft click tones during decryption sequence
      if (current % 12 === 0) {
        playSfxTone(600 + current * 4, 0.03, 'sine');
      }

      if (current >= 100) {
        clearInterval(interval);
        playSfxTone(880, 0.15, 'triangle'); // success chord
        setIsUnlocked(true);
        // Default to playing the romantic MP3 or fallback!
        playMp3FromUrl('https://drive.google.com/uc?export=download&id=1L1iyd6LxCVQ1Xyk9T32TxowexpoF7haq', 'Canción de Amor 🎵');
      }
    }, 40);
  };

  // Utility to beep sound effects via web audio without loading any resources
  const playSfxTone = (freq: number, duration: number, type: 'sine' | 'triangle' | 'square' | 'sawtooth' = 'sine') => {
    if (!audioCtxRef.current) return;
    try {
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Audio context may require click interaction on some browsers
    }
  };

  // Complex Web Audio Ambient Romantic Synthesizer
  const startSynthesizer = () => {
    initAudio();
    if (!audioCtxRef.current || !analyserRef.current) return;
    
    // Stop other audio sources
    if (htmlAudioRef.current) {
      htmlAudioRef.current.pause();
    }
    
    try {
      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }
    } catch(e){}

    setAudioSource('synth');
    setIsPlayingAudio(true);
    
    if (synthIntervalId.current) clearInterval(synthIntervalId.current);
    synthStepRef.current = 0;

    // Progression: Fmaj9 -> G6 -> Em7 -> Am7 (Extremely emotional, beautiful cinematic sequence)
    const progressions = [
      [174.61, 261.63, 329.63, 349.23, 440.00], // Fmaj9 (F, C, E, F, A)
      [196.00, 293.66, 329.63, 392.00, 493.88], // G6 (G, D, E, G, B)
      [164.81, 246.94, 329.63, 392.00, 587.33], // Em7 (E, B, E, G, D)
      [220.00, 261.63, 329.63, 440.00, 523.25]  // Am7 (A, C, E, A, C)
    ];

    const stepDuration = 220; // 220ms per note is a cozy romantic tempo
    
    synthIntervalId.current = setInterval(() => {
      const ctx = audioCtxRef.current;
      const analyser = analyserRef.current;
      if (!ctx || !analyser) return;

      const chordIdx = Math.floor(synthStepRef.current / 8) % progressions.length;
      const noteIdx = synthStepRef.current % progressions[chordIdx].length;
      const freq = progressions[chordIdx][noteIdx];

      // Play soft cinematic music box tone
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const delay = ctx.createDelay();
      const delayGain = ctx.createGain();

      // Soft warm Triangle wave
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      // Delicate tactile envelope
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 0.05); // warm attack
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.25); // romantic fading decay

      // Delay echoes
      delay.delayTime.setValueAtTime(0.38, ctx.currentTime);
      delayGain.gain.setValueAtTime(0.25, ctx.currentTime);

      // Connect
      osc.connect(gain);
      gain.connect(analyser); // Connect to analyser to drive physical particle pulsating to notes!

      gain.connect(delay);
      delay.connect(delayGain);
      delayGain.connect(analyser);
      delayGain.connect(delay); // Feedback

      osc.start();
      osc.stop(ctx.currentTime + 1.4);

      synthStepRef.current++;
    }, stepDuration);
  };

  const stopSynthesizer = () => {
    if (synthIntervalId.current) {
      clearInterval(synthIntervalId.current);
      synthIntervalId.current = null;
    }
  };

  // Handle custom file MP3 upload
  const handleMp3Upload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAudioLoading(true);
    setCustomMp3Name(file.name);
    stopSynthesizer();
    initAudio();

    if (htmlAudioRef.current) {
      htmlAudioRef.current.pause();
    }

    const fileUrl = URL.createObjectURL(file);
    const audio = new Audio(fileUrl);
    audio.crossOrigin = "anonymous";
    audio.loop = true;
    htmlAudioRef.current = audio;

    audio.addEventListener('canplaythrough', () => {
      setAudioLoading(false);
      setAudioSource('mp3');
      setIsPlayingAudio(true);
      
      const ctx = audioCtxRef.current;
      const analyser = analyserRef.current;
      
      if (ctx && analyser) {
        if (ctx.state === 'suspended') {
          ctx.resume();
        }
        
        try {
          // Reconnect media elements securely
          if (audioSourceNodeRef.current) {
            audioSourceNodeRef.current.disconnect();
          }
          const source = ctx.createMediaElementSource(audio);
          audioSourceNodeRef.current = source;
          source.connect(analyser);
        } catch (err) {
          console.warn("Audio node setup fallback:", err);
        }
      }
      
      audio.play().catch(err => {
        console.warn("La autoplay policy bloqueó el audio. Esperando click...", err);
      });
    });
  };

  // Audio Play/Pause helper
  const togglePlayAudio = () => {
    if (audioSource === 'synth') {
      if (isPlayingAudio) {
        stopSynthesizer();
        setIsPlayingAudio(false);
      } else {
        startSynthesizer();
      }
    } else if (audioSource === 'mp3' && htmlAudioRef.current) {
      if (isPlayingAudio) {
        htmlAudioRef.current.pause();
        setIsPlayingAudio(false);
      } else {
        if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
          audioCtxRef.current.resume();
        }
        htmlAudioRef.current.play().catch(() => {});
        setIsPlayingAudio(true);
      }
    } else {
      // Default to start synth
      startSynthesizer();
    }
  };

  // Generate Heart Shape Coordinates
  const getHeartPoint = (t: number) => {
    // Standard parametric heart formula
    const x = 16 * Math.pow(Math.sin(t), 3);
    const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
    return { x, y };
  };

  // Generate particles based on current config (completely populated interior and clean borders)
  const regenerateParticles = (width: number, height: number, colorPreset: ColorScheme, wordListStr: string) => {
    const listWords = wordListStr
      .split(',')
      .map(w => w.trim().toUpperCase())
      .filter(w => w.length > 0);

    const safeWords = listWords.length > 0 ? listWords : ['LOVE', 'YOU'];
    const count = particlesCount;
    const tempParticles: Particle[] = [];

    for (let i = 0; i < count; i++) {
      // Pick random t from 0 to 2PI
      const t = Math.random() * Math.PI * 2;
      const basePoint = getHeartPoint(t);
      
      let tx = 0;
      let ty = 0;
      let tag: 'shell' | 'core' = 'shell';

      // 40% crisp outer shell, 60% interior space core ("Relleno por dentro y por fuera")
      if (Math.random() < 0.40) {
        tag = 'shell';
        // Add minimal flutter to the shell border
        const spread = 0.5 + Math.random() * 1.5;
        const offsetAngle = Math.random() * Math.PI * 2;
        tx = basePoint.x * 14.5 + Math.cos(offsetAngle) * spread;
        ty = basePoint.y * 14.5 + Math.sin(offsetAngle) * spread;
      } else {
        tag = 'core';
        // Uniform solid filling mathematically bounded inside the outer threshold
        const r = Math.pow(Math.random(), 1.3); // higher concentration towards center or shell
        const spreadInside = Math.random() * 2.5;
        tx = basePoint.x * 14.5 * r + (Math.random() - 0.5) * spreadInside;
        ty = basePoint.y * 14.5 * r + (Math.random() - 0.5) * spreadInside;
      }

      // Spread initial coordinates randomly off-canvas to stream fly-in effect
      const initAngle = Math.random() * Math.PI * 2;
      const initDist = Math.max(width, height) * (0.5 + Math.random() * 0.5);

      tempParticles.push({
        id: i,
        tx: tx,
        ty: ty,
        x: width / 2 + Math.cos(initAngle) * initDist,
        y: height / 2 + Math.sin(initAngle) * initDist,
        vx: 0,
        vy: 0,
        size: Math.max(0.6, particleSize * (Math.random() * 0.7 + 0.65) * (tag === 'shell' ? 1 : 0.8)),
        alpha: Math.random() * 0.65 + 0.35,
        phase: Math.random() * Math.PI * 2,
        speedOffset: Math.random() * 0.8 + 0.3,
        tag: tag,
        word: safeWords[i % safeWords.length]
      });
    }

    particlesRef.current = tempParticles;
  };

  // Physical dynamic animation loop inside Canvas
  useEffect(() => {
    if (!isUnlocked) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    // Generate elements initially
    regenerateParticles(width, height, activeColorScheme, customWords);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      // Softly translate particles to center without resetting if possible, but regenerate for consistency
      regenerateParticles(width, height, activeColorScheme, customWords);
    };

    window.addEventListener('resize', handleResize);

    // Track frame loop
    let lastTime = 0;

    const tick = (timeMs: number) => {
      animationFrameId.current = requestAnimationFrame(tick);

      // Draw background with persistent fading trails or solid clear
      if (trailStrength < 0.99) {
        ctx.fillStyle = `rgba(0, 0, 0, ${trailStrength})`;
        ctx.fillRect(0, 0, width, height);
      } else {
        ctx.clearRect(0, 0, width, height);
      }

      // Compute musical loudness value for real-time visual beat syncing!
      let audioPulseMultiplier = 1.0;
      if (analyserRef.current && frequencyDataRef.current && isPlayingAudio) {
        analyserRef.current.getByteFrequencyData(frequencyDataRef.current);
        let sum = 0;
        for (let i = 0; i < frequencyDataRef.current.length; i++) {
          sum += frequencyDataRef.current[i];
        }
        const average = sum / frequencyDataRef.current.length;
        setLiveVolume(Math.round(average));
        // Amplify physical sizing
        audioPulseMultiplier = 1.0 + (average / 255) * 0.28;
      } else {
        setLiveVolume(0);
      }

      // Standard mathematically designed cardiac pulse
      const msPerBeat = (60 / bpm) * 1000;
      const progress = (timeMs % msPerBeat) / msPerBeat;
      
      let beatScale = 1.0;
      if (enableDoubleBeat) {
        // Human double pulse wave: lub-dub
        if (progress < 0.15) {
          const p = progress / 0.15;
          beatScale = 1.0 + 0.14 * Math.sin(p * Math.PI);
        } else if (progress < 0.25) {
          beatScale = 1.0;
        } else if (progress < 0.40) {
          const p = (progress - 0.25) / 0.15;
          beatScale = 1.0 + 0.07 * Math.sin(p * Math.PI);
        }
      } else {
        // Soft sine float
        beatScale = 1.0 + 0.10 * Math.sin(progress * Math.PI * 2);
      }

      // Adjust scale of heart depending on screen boundaries
      const baseDiameter = Math.min(width, height) / 440;
      const finalScalingFactor = baseDiameter * beatScale * audioPulseMultiplier;

      const centerX = width / 2;
      const centerY = height / 2;

      // Mouse properties
      const mouse = mouseRef.current;

      // Loop and apply physical forces to particles
      for (let i = 0; i < particlesRef.current.length; i++) {
        const p = particlesRef.current[i];

        // Soft shimmering of glowing letters
        p.phase += 0.035 * p.speedOffset;
        const shimmer = Math.sin(p.phase);

        // Gentle cosmic breeze flow drifting
        const windX = Math.sin(timeMs * 0.0012 + p.speedOffset) * 2;
        const windY = Math.cos(timeMs * 0.0008 + p.speedOffset) * 2;

        // Target target spot scaling
        const targetX = centerX + p.tx * finalScalingFactor + windX;
        const targetY = centerY + p.ty * finalScalingFactor + windY;

        // Distance delta to its home location
        const dx = targetX - p.x;
        const dy = targetY - p.y;

        // Spring stiffness: edges are slightly firmer, interior core is floatier (Snappier & more fluid)
        const stiffness = p.tag === 'shell' ? 0.22 : 0.18;
        p.vx += dx * stiffness;
        p.vy += dy * stiffness;

        // Mouse proximity repulsion physics
        if (mouse.active && mouse.x !== null && mouse.y !== null) {
          const mdx = p.x - mouse.x;
          const mdy = p.y - mouse.y;
          const mDist = Math.sqrt(mdx * mdx + mdy * mdy);

          if (mDist < repulsionRadius) {
            // Stronger repulsion near the target center
            const pushFactor = (repulsionRadius - mDist) / repulsionRadius;
            const force = pushFactor * repulsionStrength * 2.8;

            p.vx += (mdx / (mDist || 1)) * force;
            p.vy += (mdy / (mDist || 1)) * force;
          }
        }

        // Friction and velocity damping (0.78 is faster, smoother and snaps perfectly!)
        p.vx *= 0.78;
        p.vy *= 0.78;

        p.x += p.vx;
        p.y += p.vy;

        // Visual render properties
        const renderedAlpha = Math.max(0.12, Math.min(1.0, p.alpha * (0.75 + shimmer * 0.25)));
        
        ctx.save();
        ctx.globalAlpha = renderedAlpha;

        if (renderMode === 'text') {
          // Words of Love physics drawing!
          // Use slightly varied fonts for premium typographic texture
          const sizeLimit = Math.max(6, p.size * 3.8);
          ctx.font = `${p.tag === 'shell' ? 'bold' : 'normal'} ${sizeLimit}px sans-serif`;
          ctx.fillStyle = p.tag === 'shell' 
            ? (shimmer > 0.5 ? activeColorScheme.accent : activeColorScheme.primary)
            : activeColorScheme.secondary;

          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(p.word || 'LOVE', p.x, p.y);
        } else if (renderMode === 'dots') {
          // Circular particle star mode
          ctx.beginPath();
          const radius = Math.max(0.6, p.size);
          ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
          ctx.fillStyle = p.tag === 'shell' ? activeColorScheme.primary : activeColorScheme.secondary;
          ctx.fill();

          // High luminosity neon glow for selected boundary particles
          if (p.tag === 'shell' && shimmer > 0.8) {
            ctx.shadowBlur = 8;
            ctx.shadowColor = activeColorScheme.primary;
            ctx.fillStyle = activeColorScheme.accent;
            ctx.fill();
          }
        } else {
          // Hybrid: Mix text and sparkles beautifully
          if (p.id % 3 === 0) {
            const sizeLimit = Math.max(6, p.size * 3.6);
            ctx.font = `semibold ${sizeLimit}px sans-serif`;
            ctx.fillStyle = activeColorScheme.primary;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(p.word || 'YOU', p.x, p.y);
          } else {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * 0.8, 0, Math.PI * 2);
            ctx.fillStyle = activeColorScheme.secondary;
            ctx.fill();
          }
        }

        ctx.restore();
      }
    };

    animationFrameId.current = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
    };
  }, [isUnlocked, activeColorScheme, renderMode, customWords, particlesCount, bpm, particleSize, repulsionRadius, repulsionStrength, enableDoubleBeat, trailStrength, isPlayingAudio, audioSource]);

  // Handle pointer coordinate inputs to supply feed into Terminal details
  const handlePointerMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const mouse = mouseRef.current;
    mouse.x = e.clientX;
    mouse.y = e.clientY;
    mouse.active = true;

    // Smooth coords log for visual screen element
    setMouseCoords(prev => ({
      ...prev,
      targetX: e.clientX,
      targetY: e.clientY,
      x: prev.x + (e.clientX - prev.x) * 0.15,
      y: prev.y + (e.clientY - prev.y) * 0.15
    }));

    if (mouseState !== 'dispersing') {
      setMouseState('moving');
    }
  };

  const handlePointerLeave = () => {
    const mouse = mouseRef.current;
    mouse.x = null;
    mouse.y = null;
    mouse.active = false;
    setMouseState('idle');
  };

  const handlePointerDown = (e: React.MouseEvent<HTMLDivElement>) => {
    setMouseState('dispersing');
    playSfxTone(180, 0.1, 'sawtooth'); // delicate interactive thump sound when clicking particles
    initAudio();
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const handlePointerUp = () => {
    setMouseState('moving');
  };

  // Standalone HTML code bundle trigger Download
  const handleExportHTML = () => {
    const customConfig: ParticleConfig = {
      particlesCount,
      bpm,
      colorScheme: activeColorScheme.id,
      particleSize,
      repulsionRadius,
      repulsionStrength,
      trailStrength,
      enableDoubleBeat,
      shimmerSpeed: 1,
      flowSpeed: 1,
      renderMode,
      loveWords: customWords
    };

    const standaloneText = generateStandaloneHTML(customConfig, activeColorScheme, COLOR_PRESETS);
    const blob = new Blob([standaloneText], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `corazon_particulas_${activeColorScheme.id}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div 
      className="w-full h-screen bg-black flex flex-col font-mono text-zinc-400 overflow-hidden relative selection:bg-pink-500/20"
      onMouseMove={handlePointerMove}
      onMouseLeave={handlePointerLeave}
      onMouseDown={handlePointerDown}
      onMouseUp={handlePointerUp}
    >
      
      {/* 1. LOCK SCREEN DECIFRADOR (PRE-ENTRY PORTAL) */}
      {!isUnlocked && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/95 flex-col px-6">
          <div className="w-full max-w-lg border border-zinc-800 bg-zinc-950/80 backdrop-blur-md p-8 rounded-sm shadow-[0_0_50px_rgba(244,63,94,0.05)] relative overflow-hidden">
            
            {/* Ambient radar grid lines in dark theme */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none opacity-40"></div>
            
            <div className="relative z-10 space-y-6">
              
              {/* Header */}
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 border border-rose-500/40 flex items-center justify-center">
                    <span className="w-1.5 h-1.5 bg-rose-500 animate-pulse"></span>
                  </div>
                  <span className="text-xs uppercase tracking-widest text-zinc-500">ENCRYPTION ENGINE v3</span>
                </div>
                <div className="text-[10px] text-zinc-600 bg-zinc-900 px-2 py-0.5 rounded-xs font-mono">
                  LOCK_STATUS: EXPLICIT
                </div>
              </div>

              {/* Central scramble decryption monitor */}
              <div className="p-4 bg-zinc-950 border border-zinc-900 rounded-xs space-y-3 font-mono">
                <div className="flex items-center justify-between text-[11px] text-zinc-500 mb-1">
                  <span>DISPOSITIVO SECTOR</span>
                  <span>IP_ROUTE: LOCALHOST:3000</span>
                </div>
                <div className="text-sm tracking-widest font-mono font-medium text-rose-500 break-all select-none">
                  {decryptText}
                </div>
                <div className="text-[10px] text-zinc-600 leading-relaxed font-mono">
                  SISTEMA DE PARTÍCULAS CARDIÁCO BLOQUEADO. SE REQUIERE INTERACCIÓN COGNITIVA PARA LA INICIALIZACIÓN DEL SISTEMA DEL CORAZÓN DE UN MILLÓN DE PALABRAS.
                </div>
              </div>

              {/* Progress Bar */}
              {isDecrypting && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[9px] uppercase tracking-wider text-rose-400">
                    <span>Descifrando algoritmo de amor cardíaco...</span>
                    <span>{decryptionProgress}%</span>
                  </div>
                  <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden relative">
                    <div 
                      className="h-full bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.8)] transition-all duration-100 ease-out"
                      style={{ width: `${decryptionProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Intercept Trigger Button */}
              {!isDecrypting ? (
                <button 
                  onClick={handleDecrypt}
                  className="w-full cursor-pointer bg-zinc-900 hover:bg-rose-950/30 border border-zinc-800 hover:border-rose-500/50 py-3.5 text-xs uppercase text-zinc-100 tracking-widest transition-all duration-300 flex items-center justify-center gap-2 group hover:shadow-[0_0_15px_rgba(244,63,94,0.1)] rounded-xs"
                >
                  <Unlock className="w-3.5 h-3.5 text-rose-500 group-hover:rotate-12 transition-transform" />
                  DECIFRAS MENSAJE CORRETO
                </button>
              ) : (
                <div className="py-3.5 text-center text-rose-500/80 animate-pulse text-[11px] tracking-widest uppercase">
                  INICIALIZANDO RENDERIZADO MATEMÁTICO...
                </div>
              )}

              {/* Footer */}
              <div className="text-[9px] text-center text-zinc-600 uppercase tracking-widest pt-2">
                PRESIONE PARA CARGAR LA AMBIENTACIÓN NEÓN Y SINTETIZADOR
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. MAIN APP COMPONENT VIEW - GLOWING HEART PORTAL */}
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 z-0 bg-black cursor-crosshair"
      />

      {/* 3. TERMINAL APP HEADER (Elegant Dark design styling) */}
      <header className="relative z-10 flex flex-wrap justify-between items-center px-6 py-4 border-b border-white/5 bg-black/40 backdrop-blur-sm pointer-events-auto gap-4">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 border border-rose-500 flex items-center justify-center bg-rose-950/20">
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 animate-heartbeat" style={{ animation: `bounce ${60 / bpm}s infinite` }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-[10px] tracking-[0.25em] uppercase text-zinc-500 font-bold">System Terminal</h1>
              <span className="text-[9px] text-zinc-600 bg-zinc-900/80 border border-zinc-800 px-1.5 py-0.2 rounded-xs font-mono font-normal">HEARTPLAY_V2_PRO</span>
            </div>
            <p className="text-base text-white tracking-widest font-mono uppercase font-bold text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-rose-400">
              UN MILLÓN DE PALABRAS DE AMOR
            </p>
          </div>
        </div>

        {/* Live diagnostics status outputs */}
        <div className="hidden md:flex gap-8 text-[10px] uppercase tracking-widest font-mono">
          <div className="flex flex-col border-l border-zinc-850 pl-4">
            <span className="text-zinc-650">BPM Rate</span>
            <span className="text-rose-500 font-bold tracking-tight">{bpm} BPM</span>
          </div>
          <div className="flex flex-col border-l border-zinc-850 pl-4">
            <span className="text-zinc-650">Relleno Partículas</span>
            <span className="text-white font-bold tracking-tight">{particlesCount} palabras</span>
          </div>
          <div className="flex flex-col border-l border-zinc-850 pl-4">
            <span className="text-zinc-650">Sistema Audio</span>
            <span className="text-zinc-400 font-semibold lowercase">
              {audioSource === 'synth' ? '🎹 sintetizador' : audioSource === 'mp3' ? '🎵 mp3 subido' : 'silencioso'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Main Download standalone HTML btn */}
          <button 
            onClick={handleExportHTML}
            title="Descargar archivo .html único autónomo"
            className="cursor-pointer bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-rose-500/50 hover:bg-zinc-850/50 text-[11px] px-3.5 py-2.5 transition-all flex items-center gap-2 rounded-xs group"
          >
            <FileDown className="w-3.5 h-3.5 text-rose-500 group-hover:translate-y-0.5 transition-transform" />
            <span className="hidden sm:inline">Exportar index.html</span>
          </button>

          {/* Toggle configuration panel drawer */}
          <button 
            onClick={() => setShowControlPanel(!showControlPanel)}
            className={`w-10 h-10 border flex items-center justify-center transition-all cursor-pointer rounded-xs ${
              showControlPanel ? 'border-rose-500 bg-rose-950/20 text-white' : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white hover:border-zinc-700'
            }`}
            title="Panel de Configuración de Corazón"
          >
            <Settings className={`w-4 h-4 ${showControlPanel ? 'animate-spin' : ''}`} style={{ animationDuration: '10s' }} />
          </button>
        </div>
      </header>

      {/* 4. MAIN CENTRAL CONTENT flex block */}
      <main className="flex-1 flex pointer-events-none relative">
        
        {/* LEFT INFORMATION DECOR (Coordinate Stream and Grid Monitor) */}
        <aside className="absolute left-6 bottom-6 z-15 flex flex-col gap-5 pointer-events-auto max-w-xs transition-opacity duration-300 opacity-90">
          <div className="p-4 border border-white/5 bg-black/55 backdrop-blur-md rounded-xs space-y-3 font-mono">
            <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
              <span className="text-[9px] text-zinc-600 uppercase tracking-widest">Physics Monitor</span>
              <span className="text-[8px] px-1.5 py-0.2 bg-emerald-950 text-emerald-400 rounded-2xs font-mono">LIVE_STREAM</span>
            </div>
            
            <div className="text-[10px] space-y-1 text-zinc-500 font-mono leading-relaxed">
              <p className="flex justify-between">
                <span>CURS_X:</span> 
                <span className="text-zinc-200">{Math.round(mouseCoords.targetX)} px</span>
              </p>
              <p className="flex justify-between">
                <span>CURS_Y:</span> 
                <span className="text-zinc-200">{Math.round(mouseCoords.targetY)} px</span>
              </p>
              <p className="flex justify-between">
                <span>REACTION_VAL:</span> 
                <span className={mouseState === 'dispersing' ? 'text-rose-455' : 'text-zinc-400'}>
                  {mouseState.toUpperCase()}
                </span>
              </p>
              {isPlayingAudio && (
                <p className="flex justify-between">
                  <span>AUDIO_FREQ_INDEX:</span> 
                  <span className="text-pink-400 font-bold">{liveVolume} / 255</span>
                </p>
              )}
            </div>
            
            <p className="text-[9px] leading-relaxed text-zinc-600 uppercase pt-2 border-t border-white/5 font-mono">
              El corazón está completamente computado con miles de partículas de amor redundantes tanto en su contorno como en su espacio interior.
            </p>
          </div>
        </aside>

        {/* FLOATING ACTION FLOATING MUSIC PLAYER BUTTONS (Sleek minimalist panel at top right) */}
        <div className="absolute right-6 top-6 z-15 pointer-events-auto flex flex-col gap-2">
          
          {/* Quick Sound Controller block */}
          <div className="p-3 bg-black/60 border border-white/5 backdrop-blur-md flex items-center gap-3 rounded-xs shadow-lg">
            <div className="w-8 h-8 rounded-sm bg-neutral-900 border border-zinc-800 flex items-center justify-center">
              <Music className="w-4 h-4 text-rose-500 animate-pulse" />
            </div>
            <div>
              <div className="text-[9px] text-zinc-500 font-mono uppercase">Reproducción Automática</div>
              <div className="text-[10px] text-zinc-200 font-mono font-bold max-w-[120px] truncate">
                {audioSource === 'synth' ? 'Sinfonía de Amor 🎹' : customMp3Name ? customMp3Name : 'Silencioso'}
              </div>
            </div>
            <button
              onClick={togglePlayAudio}
              className="cursor-pointer ml-2 w-8 h-8 rounded-xs hover:border-rose-500 bg-rose-550 hover:bg-rose-600 border border-rose-500/30 flex items-center justify-center text-white transition-all transform hover:scale-105"
            >
              {isPlayingAudio ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-white" />}
            </button>
          </div>

          {/* Quick instructions indicator details box */}
          <div className="hidden sm:block p-3 bg-neutral-950/40 border border-zinc-900 rounded-xs text-[10px] text-zinc-450 font-mono text-right max-w-xs leading-normal">
            ✦ Haz click sobre el tapiz negro para dispersar suavemente la constelación. Las palabras volverán de inmediato a la geometría central.
          </div>
        </div>

        {/* RIGHT SIDE PARAMETERS DRAWER CONTROL BOARD */}
        <aside className={`absolute right-6 bottom-6 top-24 z-20 w-80 bg-neutral-950/75 border border-zinc-800/80 backdrop-blur-xl p-5 overflow-y-auto pointer-events-auto transition-transform duration-300 rounded-sm space-y-5 shadow-2xl flex flex-col ${
          showControlPanel ? 'translate-x-0' : 'translate-x-[360px]'
        }`}>
          
          <div className="flex items-center justify-between border-b border-zinc-900 pb-3 flex-shrink-0">
            <span className="text-[11px] font-bold text-zinc-400 tracking-wider uppercase flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-rose-500" />
              Parámetros de Diseño
            </span>
            <button 
              onClick={() => setShowControlPanel(false)}
              className="text-xs text-zinc-650 hover:text-zinc-400 select-none cursor-pointer"
            >
              CERRAR ✕
            </button>
          </div>

          <div className="space-y-4 flex-1">
            
            {/* Color Palette Presets Selection Grid */}
            <div className="space-y-2">
              <label className="text-[9px] uppercase tracking-widest text-zinc-600 block">✨ Espectro de Color (Neón)</label>
              <div className="grid grid-cols-2 gap-2">
                {COLOR_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setActiveColorScheme(preset)}
                    className={`cursor-pointer px-2.5 py-2 text-[10px] text-left font-mono rounded-xs border transition-all flex items-center gap-2 ${
                      activeColorScheme.id === preset.id
                        ? 'bg-rose-950/20 border-rose-500 text-white shadow-[0_0_8px_rgba(244,63,94,0.15)]'
                        : 'bg-zinc-950 border-zinc-900 text-zinc-455 hover:bg-zinc-900 hover:text-zinc-200'
                    }`}
                  >
                    <span 
                      className="w-1.5 h-1.5 rounded-full inline-block flex-shrink-0 shadow-sm" 
                      style={{ 
                        backgroundColor: preset.primary,
                        boxShadow: `0 0 6px ${preset.primary}`
                      }}
                    />
                    <span className="truncate">{preset.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Render Mode Switch: text / dots / hybrid */}
            <div className="space-y-2">
              <label className="text-[9px] uppercase tracking-widest text-zinc-600 block">🎨 Modo de Renderizado</label>
              <div className="grid grid-cols-3 gap-1.5 bg-neutral-900/60 p-1 border border-zinc-850 rounded-xs">
                {(['text', 'dots', 'hybrid'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setRenderMode(mode)}
                    className={`cursor-pointer py-1.5 text-[9px] text-center font-bold font-mono tracking-tighter uppercase transition-colors rounded-xs ${
                      renderMode === mode 
                        ? 'bg-zinc-800 text-white' 
                        : 'text-zinc-600 hover:text-zinc-350'
                    }`}
                  >
                    {mode === 'text' ? 'Palabras' : mode === 'dots' ? 'Puntos' : 'Mixto'}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom customizable words list if renderMode is text or hybrid */}
            {(renderMode === 'text' || renderMode === 'hybrid') && (
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase tracking-widest text-rose-450 block font-bold">✍ Tus Palabras de Amor</label>
                <textarea
                  value={customWords}
                  onChange={(e) => setCustomWords(e.target.value)}
                  placeholder="Escribe palabras separadas por comas"
                  className="w-full bg-zinc-950 hover:bg-zinc-900/80 text-zinc-200 font-mono text-[10px] p-2.5 border border-zinc-850 hover:border-zinc-700 outline-none focus:border-rose-500 rounded-xs transition-all tracking-wider font-light resize-none h-14"
                />
                <span className="text-[8px] text-zinc-600 block uppercase">
                  Genera instantáneamente un corazón con tus propios nombres o mensajes personalizados.
                </span>
              </div>
            )}

            {/* Dynamic Music Controller Dashboard */}
            <div className="space-y-2.5 border-t border-zinc-900 pt-3">
              <label className="text-[9px] uppercase tracking-widest text-zinc-600 block">🎵 Canal de Música de Fondo</label>
              
              <div className="space-y-2">
                {/* 1. File Uploader component */}
                <div className="relative group border border-dashed border-zinc-800 hover:border-rose-500/40 bg-zinc-950/60 p-3 text-center transition-all rounded-xs">
                  <input 
                    type="file" 
                    accept="audio/*" 
                    onChange={handleMp3Upload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    title="Arrastra o sube tu archivo MP3"
                  />
                  <div className="flex flex-col items-center justify-center gap-1.5 pointer-events-none">
                    <Upload className="w-4 h-4 text-zinc-500 group-hover:text-rose-550 transition-colors" />
                    <span className="text-[9px] text-zinc-400 uppercase tracking-tighter block">
                      {customMp3Name ? '✅ Cambiar Archivo MP3' : 'Sube tu canción (.mp3)'}
                    </span>
                    {customMp3Name && (
                      <span className="text-[8px] text-rose-400 font-semibold truncate max-w-[200px]">
                        {customMp3Name}
                      </span>
                    )}
                  </div>
                </div>

                {/* Synth / default selections */}
                <div className="flex gap-2">
                  <button 
                    onClick={() => startSynthesizer()}
                    className={`cursor-pointer flex-1 py-1.5 text-[9px] font-bold uppercase rounded-xs border transition-colors ${
                      audioSource === 'synth' 
                        ? 'border-rose-500 text-white bg-rose-950/10' 
                        : 'border-zinc-850 text-zinc-555 hover:text-zinc-200 hover:border-zinc-755'
                    }`}
                  >
                    Sintetizador 🎹
                  </button>
                  <button 
                    onClick={() => {
                      stopSynthesizer();
                      if (htmlAudioRef.current) htmlAudioRef.current.pause();
                      setAudioSource('none');
                      setIsPlayingAudio(false);
                    }}
                    className={`cursor-pointer py-1.5 px-3 text-[9px] font-bold uppercase rounded-xs border transition-colors border-zinc-850 text-zinc-555 hover:text-rose-400 hover:border-rose-900`}
                  >
                    Mudo
                  </button>
                </div>
              </div>
            </div>

            {/* Parameters sliders block */}
            <div className="space-y-3.5 border-t border-zinc-900 pt-3">
              <label className="text-[9px] uppercase tracking-widest text-zinc-600 block">⚙ Ajustes de Partículas</label>

              {/* Number of Particles */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-zinc-400 font-mono">
                  <span>Densidad</span>
                  <span className="text-zinc-100 font-bold">{particlesCount} palabras</span>
                </div>
                <input 
                  type="range" 
                  min={500} 
                  max={3500} 
                  step={100}
                  value={particlesCount}
                  onChange={(e) => setParticlesCount(parseInt(e.target.value))}
                  className="w-full accent-rose-500 h-1 bg-zinc-900 rounded-lg cursor-pointer"
                />
              </div>

              {/* Heart bpm */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-zinc-400 font-mono">
                  <span>Ritmo Latido (BPM)</span>
                  <span className="text-rose-500 font-bold">{bpm} BPM</span>
                </div>
                <input 
                  type="range" 
                  min={30} 
                  max={140} 
                  step={1}
                  value={bpm}
                  onChange={(e) => setBpm(parseInt(e.target.value))}
                  className="w-full accent-rose-500 h-1 bg-zinc-900 rounded-lg cursor-pointer"
                />
              </div>

              {/* Particle Size */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-zinc-400 font-mono">
                  <span>Tamaño Fuente / Puntos</span>
                  <span className="text-zinc-100 font-bold">{particleSize}px</span>
                </div>
                <input 
                  type="range" 
                  min={1.2} 
                  max={4.5} 
                  step={0.1}
                  value={particleSize}
                  onChange={(e) => setParticleSize(parseFloat(e.target.value))}
                  className="w-full accent-rose-500 h-1 bg-zinc-900 rounded-lg cursor-pointer"
                />
              </div>

              {/* Force repulsion Radius */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-zinc-400 font-mono">
                  <span>Radio de Contacto</span>
                  <span className="text-zinc-100 font-bold">{repulsionRadius}px</span>
                </div>
                <input 
                  type="range" 
                  min={60} 
                  max={250} 
                  value={repulsionRadius}
                  onChange={(e) => setRepulsionRadius(parseInt(e.target.value))}
                  className="w-full accent-rose-500 h-1 bg-zinc-900 rounded-lg cursor-pointer"
                />
              </div>

              {/* Trail Toggle */}
              <div className="flex justify-between items-center text-[10px] text-zinc-400 border-t border-zinc-900/60 pt-2.5">
                <span className="uppercase text-[9px] text-zinc-500">Estructura Estelas (Trails)</span>
                <button
                  onClick={() => setTrailStrength(trailStrength === 1.0 ? 0.12 : 1.0)}
                  className={`cursor-pointer px-2 py-0.5 border text-[9px] transition-colors rounded-xs uppercase ${
                    trailStrength < 0.99 
                      ? 'border-rose-500 text-rose-500 bg-rose-950/10' 
                      : 'border-zinc-800 text-zinc-650 hover:text-zinc-400'
                  }`}
                >
                  {trailStrength < 0.99 ? 'Activado' : 'Limpieza'}
                </button>
              </div>

              {/* Double cardiac sync */}
              <div className="flex justify-between items-center text-[10px] text-zinc-400">
                <span className="uppercase text-[9px] text-zinc-500">Latidos Dobles (Lub-Dub)</span>
                <button
                  onClick={() => setEnableDoubleBeat(!enableDoubleBeat)}
                  className={`cursor-pointer px-2 py-0.5 border text-[9px] transition-colors rounded-xs uppercase ${
                    enableDoubleBeat 
                      ? 'border-rose-500 text-rose-500 bg-rose-950/10' 
                      : 'border-zinc-800 text-zinc-650 hover:text-zinc-400'
                  }`}
                >
                  {enableDoubleBeat ? 'Humano' : 'Sinusoidal'}
                </button>
              </div>

            </div>

          </div>

          <div className="pt-2 border-t border-zinc-900 flex-shrink-0 flex gap-2">
            <button
              onClick={() => {
                setParticlesCount(2000);
                setBpm(65);
                setParticleSize(2.3);
                setRepulsionRadius(120);
                setRepulsionStrength(10);
                setEnableDoubleBeat(true);
                setTrailStrength(0.12);
                setRenderMode('text');
                setCustomWords('LOVE, YOU');
                setActiveColorScheme(COLOR_PRESETS[0]);
              }}
              className="cursor-pointer flex-1 py-2 border border-zinc-800 text-zinc-500 hover:text-zinc-350 hover:bg-zinc-900 text-[10px] text-center rounded-xs transition-all uppercase"
            >
              Restablecer Valores
            </button>
          </div>

        </aside>

      </main>

      {/* 5. SYSTEM STATUS CORE BAR FOOTER */}
      <footer className="relative z-10 h-10 border-t border-white/5 flex items-center px-6 justify-between bg-black/60 backdrop-blur-sm pointer-events-none text-[10px] uppercase tracking-widest text-zinc-650">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_6px_#f43f5e] animate-ping"></span>
          <span>Engine: Web Audio & Canvas Text-Particles v3.1</span>
        </div>
        <div className="hidden sm:inline italic">
          Google AI Studio | Interfaz de Latido de Neón Conectada
        </div>
      </footer>

    </div>
  );
}
