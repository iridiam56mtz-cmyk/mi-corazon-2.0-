/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ColorScheme {
  id: string;
  name: string;
  primary: string;    // Core neon color (e.g. #ff2a5f)
  secondary: string;  // Ambient highlight color (e.g. #ff758c)
  accent: string;     // Bright spark color (e.g. #ffffff)
  shadow: string;     // Glow shadow color
}

export interface ParticleConfig {
  particlesCount: number;
  bpm: number;
  colorScheme: string;
  particleSize: number;
  repulsionRadius: number;
  repulsionStrength: number;
  trailStrength: number; // 0.05 to 1.0 (1.0 means no trail)
  enableDoubleBeat: boolean;
  shimmerSpeed: number;
  flowSpeed: number;
  renderMode: 'text' | 'dots' | 'hybrid';
  loveWords: string; // comma separated list of words to assign to particles
}

export interface Particle {
  id: number;
  tx: number;       // target X coordinate (relative to center)
  ty: number;       // target Y coordinate (relative to center)
  x: number;        // current X coordinate (absolute px)
  y: number;        // current Y coordinate (absolute px)
  vx: number;       // velocity X
  vy: number;       // velocity Y
  size: number;     // calculated particle size
  alpha: number;    // base transparency (0.1 to 1.0)
  phase: number;    // phase offset for sinusoidal shimmer or fluctuation
  speedOffset: number; // custom multiplier for float speeds
  tag: 'shell' | 'core'; // outer border vs inner volume
  word?: string;    // specific word assigned if in text mode
}
