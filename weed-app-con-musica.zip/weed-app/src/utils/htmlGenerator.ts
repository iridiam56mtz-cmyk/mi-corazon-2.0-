/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ParticleConfig, ColorScheme } from '../types';

export function generateStandaloneHTML(config: ParticleConfig, currentPreset: ColorScheme, presets: ColorScheme[]): string {
  // Let's create a beautiful standalone HTML representation of our interactive particle heart.
  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Corazón de Partículas Interactivo</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      user-select: none;
    }
    body, html {
      width: 100%;
      height: 100%;
      overflow: hidden;
      background-color: #000000;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      color: #ffffff;
    }
    
    #canvas {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      display: block;
    }

    /* Decryption overlay lock screen */
    #decrypt-screen {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: #000000;
      z-index: 100;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 24px;
      transition: opacity 0.6s ease, transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .decrypt-container {
      width: 100%;
      max-width: 500px;
      background: rgba(10, 10, 10, 0.85);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 8px;
      padding: 30px;
      backdrop-filter: blur(12px);
      box-shadow: 0 10px 40px rgba(0,0,0,0.8);
      position: relative;
    }

    .decrypt-hdr {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      padding-bottom: 12px;
      margin-bottom: 20px;
    }

    .decrypt-tag {
      font-size: 10px;
      background: #111;
      border: 1px solid rgba(255, 255, 255, 0.05);
      padding: 3px 8px;
      color: #888;
      font-family: 'JetBrains Mono', monospace;
    }

    .scramble-box {
      background: #000;
      border: 1px solid rgba(255, 255, 255, 0.04);
      padding: 16px;
      font-family: 'JetBrains Mono', monospace;
      color: var(--theme-color, #ff2a5f);
      font-size: 0.9rem;
      letter-spacing: 0.1em;
      text-align: center;
      margin-bottom: 20px;
      word-break: break-all;
    }

    .desc {
      font-size: 11px;
      color: #666;
      line-height: 1.6;
      margin-bottom: 24px;
      text-align: justify;
    }

    .progress-wrap {
      margin-bottom: 24px;
      display: none;
    }

    .progress-header {
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: var(--theme-color, #ff2a5f);
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .progress-bar-bg {
      width: 100%;
      height: 3px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      overflow: hidden;
    }

    .progress-bar-fg {
      height: 100%;
      width: 0%;
      background: var(--theme-color, #ff2a5f);
      box-shadow: 0 0 10px var(--theme-color, #ff2a5f);
      transition: width 0.05s linear;
    }

    .unlock-btn {
      width: 100%;
      background: #111;
      border: 1px solid rgba(255,255,255,0.1);
      color: #fff;
      padding: 14px;
      font-size: 11px;
      font-family: 'JetBrains Mono', monospace;
      letter-spacing: 0.15em;
      cursor: pointer;
      text-transform: uppercase;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }

    .unlock-btn:hover {
      background: rgba(var(--theme-color-rgb), 0.1);
      border-color: var(--theme-color, #ff2a5f);
      box-shadow: 0 0 20px rgba(var(--theme-color-rgb), 0.15);
    }

    /* Outer margin decor (Architectural Honesty: elegant humanistic minimalist title) */
    .title-banner {
      position: absolute;
      top: 24px;
      left: 24px;
      z-index: 10;
      pointer-events: none;
    }
    .title-banner h1 {
      font-size: 1.1rem;
      font-weight: 500;
      letter-spacing: -0.025em;
      color: #f3f4f6;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .title-banner p {
      font-size: 0.75rem;
      font-family: 'JetBrains Mono', monospace;
      color: #6b7280;
      margin-top: 4px;
    }

    /* Hover instructions badge */
    .interaction-badge {
      position: absolute;
      bottom: 24px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 10;
      background: rgba(15, 15, 15, 0.65);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 100px;
      padding: 6px 14px;
      font-size: 0.75rem;
      font-family: 'JetBrains Mono', monospace;
      color: #9ca3af;
      pointer-events: none;
      letter-spacing: -0.011em;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      gap: 6px;
      animation: breathe 3s ease-in-out infinite;
    }

    @keyframes breathe {
      0%, 100% { opacity: 0.6; transform: translate(-50%, 0) scale(0.98); }
      50% { opacity: 0.95; transform: translate(-50%, 0) scale(1.02); }
    }

    /* Floating Control Panel */
    .control-panel {
      position: absolute;
      right: 24px;
      top: 24px;
      z-index: 20;
      width: 320px;
      background: rgba(10, 10, 10, 0.75);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 16px;
      padding: 20px;
      box-shadow: 0 10px 45px rgba(0, 0, 0, 0.8);
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s ease;
      height: calc(100% - 48px);
      overflow-y: auto;
    }

    .control-panel.collapsed {
      transform: translateX(360px);
      opacity: 0.5;
    }

    .panel-toggle {
      position: absolute;
      right: 24px;
      top: 24px;
      z-index: 30;
      background: rgba(15, 15, 15, 0.8);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: #e5e7eb;
      width: 40px;
      height: 40px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      backdrop-filter: blur(8px);
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
      transition: all 0.2s ease;
    }
    .panel-toggle:hover {
      background: rgba(25, 25, 25, 0.9);
      border-color: rgba(255, 255, 255, 0.2);
      transform: scale(1.05);
    }
    
    .panel-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
      padding-bottom: 12px;
    }
    .panel-header h2 {
      font-size: 0.9rem;
      text-transform: uppercase;
      font-family: 'JetBrains Mono', monospace;
      letter-spacing: 0.05em;
      color: #9ca3af;
    }

    .section-title {
      font-size: 0.75rem;
      font-family: 'JetBrains Mono', monospace;
      color: #6b7280;
      text-transform: uppercase;
      margin-bottom: 10px;
      letter-spacing: 0.05em;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .control-group {
      margin-bottom: 20px;
    }

    /* Preset color bubbles grid */
    .presets-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    .preset-btn {
      flex: 1 1 calc(50% - 4px);
      background: rgba(30, 30, 30, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 8px;
      padding: 8px 10px;
      font-size: 0.75rem;
      color: #d1d5db;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      text-align: left;
    }
    .preset-btn:hover {
      background: rgba(40, 40, 40, 0.6);
      border-color: rgba(255, 255, 255, 0.15);
    }
    .preset-btn.active {
      background: rgba(255, 255, 255, 0.08);
      border-color: var(--theme-color);
      color: #ffffff;
      box-shadow: 0 0 10px rgba(var(--theme-color-rgb), 0.2);
    }
    .color-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    /* Sliders */
    .slider-container {
      margin-bottom: 14px;
    }
    .slider-header {
      display: flex;
      justify-content: space-between;
      font-size: 0.75rem;
      color: #cbd5e1;
      margin-bottom: 6px;
    }
    .slider-val {
      font-family: 'JetBrains Mono', monospace;
      color: var(--theme-color, #ff2a5f);
    }
    input[type=range] {
      -webkit-appearance: none;
      width: 100%;
      height: 4px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 2px;
      outline: none;
      margin: 8px 0;
    }
    input[type=range]::-webkit-slider-thumb {
      -webkit-appearance: none;
      appearance: none;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #ffffff;
      box-shadow: 0 0 8px var(--theme-color, #ff2a5f);
      cursor: pointer;
      transition: transform 0.1s ease;
    }
    input[type=range]::-webkit-slider-thumb:hover {
      transform: scale(1.3);
    }

    /* Checkbox list */
    .checkbox-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 0;
      font-size: 0.8rem;
      color: #cbd5e1;
    }
    .switch {
      position: relative;
      display: inline-block;
      width: 32px;
      height: 18px;
    }
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    .toggle-slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(255, 255, 255, 0.1);
      transition: .3s;
      border-radius: 34px;
    }
    .toggle-slider:before {
      position: absolute;
      content: "";
      height: 12px;
      width: 12px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: .3s;
      border-radius: 50%;
    }
    input:checked + .toggle-slider {
      background-color: var(--theme-color, #ff2a5f);
    }
    input:checked + .toggle-slider:before {
      transform: translateX(14px);
    }

    /* Text area */
    textarea {
      width: 100%;
      background: #000;
      border: 1px solid rgba(255,255,255,0.08);
      font-family: inherit;
      color: #eee;
      padding: 10px;
      font-size: 11px;
      outline: none;
      border-radius: 8px;
      resize: none;
      margin-bottom: 12px;
    }
    textarea:focus {
      border-color: var(--theme-color, #ff2a5f);
    }

    /* Audio Box decoration */
    .audio-wrapper {
      background: rgba(0,0,0,0.5);
      border: 1px dashed rgba(255,255,255,0.1);
      padding: 15px;
      border-radius: 8px;
      text-align: center;
      position: relative;
      margin-bottom: 20px;
    }
    .audio-wrapper input[type=file] {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      opacity: 0;
      cursor: pointer;
    }

    /* Actions and info */
    .panel-footer {
      margin-top: 15px;
      padding-top: 15px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .footer-btn {
      width: 100%;
      padding: 10px;
      border-radius: 8px;
      font-family: inherit;
      font-size: 0.8rem;
      font-weight: 500;
      cursor: pointer;
      text-align: center;
      transition: all 0.2s ease;
    }
    .btn-primary {
      background: rgba(255, 255, 255, 0.05);
      color: #ffffff;
      border: 1px solid rgba(255, 255, 255, 0.15);
    }
    .btn-primary:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: var(--theme-color);
      box-shadow: 0 0 15px rgba(var(--theme-color-rgb), 0.15);
    }

    /* Radio selections styling */
    .radio-grid {
      display: flex;
      background: rgba(255,255,255,0.02);
      border: 1px solid rgba(255,255,255,0.06);
      padding: 4px;
      border-radius: 8px;
      margin-bottom: 12px;
    }
    .radio-option {
      flex: 1;
      text-align: center;
      padding: 6px;
      font-size: 10px;
      font-family: 'JetBrains Mono', monospace;
      color: #888;
      cursor: pointer;
      border-radius: 4px;
      text-transform: uppercase;
    }
    .radio-option.selected {
      background: rgba(255,255,255,0.08);
      color: #fff;
    }
  </style>
</head>
<body>

  <!-- 1. DECIFRAS MENSAJE LOCK SCREEN OVERLAY -->
  <div id="decrypt-screen">
    <div class="decrypt-container">
      <div class="decrypt-hdr">
        <span style="font-weight: 600; font-size: 11px; letter-spacing: 0.1em; color: #888;">ROMANTIC DECRYPT ENGINE</span>
        <span class="decrypt-tag">ESTADO: CONFIDENCIAL</span>
      </div>
      
      <div class="scramble-box" id="scramble-el">
        DECIFRAS MENSAJE CORRETO
      </div>

      <div class="desc">
        SISTEMA CRIPTOGRÁFICO DE AMOR DETECTADO. AL PRESIONAR EL EXECUTOR CENTRAL SE COMENZARÁ A DESENCRIPTAR LA FRECUENCIA CARDIÁCA Y EL SINTETIZADOR DE AMOR SE ACTIVARÁ AUTOMÁTICAMENTE PARA REPRODUCIR LA CANCIÓN DE FONDO EN MP3.
      </div>

      <!-- Progressive decoder animation bar -->
      <div class="progress-wrap" id="progress-wrapper">
        <div class="progress-header">
          <span>Descifrando constelación de palabras de amor...</span>
          <span id="progress-txt">0%</span>
        </div>
        <div class="progress-bar-bg">
          <div class="progress-bar-fg" id="progress-bar"></div>
        </div>
      </div>

      <button class="unlock-btn" id="unlock-trigger">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
        </svg>
        Descifrar Código Corazón
      </button>
    </div>
  </div>

  <!-- Background Canvas -->
  <canvas id="canvas"></canvas>

  <!-- Title Indicator -->
  <div class="title-banner">
    <h1>
      <span style="color: var(--theme-color, #ff2a5f)">❤</span>
      Corazón de Partículas
    </h1>
    <p id="bpmlogs">RITMO CARDIÁCO COMPLETO: ${config.bpm} BPM</p>
  </div>

  <!-- Instruction Badge -->
  <div class="interaction-badge">
    <span>✦</span> MUEVE EL CURSOR O TOCA LA PANTALLA PARA DISPERSAR <span>✦</span>
  </div>

  <!-- Panel Toggle Button -->
  <button class="panel-toggle" id="toggle-btn" title="Configuración">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="3"></circle>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
    </svg>
  </button>

  <!-- Floating Config UI -->
  <div class="control-panel" id="panel">
    <div class="panel-header">
      <h2>CONTROLES</h2>
    </div>

    <!-- Color Presets -->
    <div class="control-group">
      <div class="section-title">✨ PALETA DE COLOR</div>
      <div class="presets-grid" id="presets-container">
        <!-- Rendered in script -->
      </div>
    </div>

    <!-- Render Modes -->
    <div class="control-group">
      <div class="section-title">🎨 TIPO DE PARTICULA</div>
      <div class="radio-grid" id="rendermode-grid">
        <div class="radio-option ${config.renderMode === 'text' ? 'selected' : ''}" data-val="text">Palabras</div>
        <div class="radio-option ${config.renderMode === 'dots' ? 'selected' : ''}" data-val="dots">Puntos</div>
        <div class="radio-option ${config.renderMode === 'hybrid' ? 'selected' : ''}" data-val="hybrid">Mixto</div>
      </div>
    </div>

    <!-- Customizable list words -->
    <div class="control-group" id="words-wrap">
      <div class="section-title">✍ TUS PALABRAS PERSONALIZADAS</div>
      <textarea id="words-text" rows="2" placeholder="LOVE, YOU"></textarea>
    </div>

    <!-- Back music uploader -->
    <div class="control-group">
      <div class="section-title">🎵 CANCIÓN DETRÁS (MP3)</div>
      
      <!-- local browser MP3 loader -->
      <div class="audio-wrapper">
        <span style="font-size: 10px; color: #aaa; text-transform: uppercase;" id="mp3-lbl">Sube tu música (.mp3)</span>
        <input type="file" id="mp3-uploader" accept="audio/*">
      </div>

      <!-- Quick mute/unmute synth audio selector -->
      <div class="presets-grid">
        <button class="preset-btn font-mono text-[9px]" id="synth-btn" style="flex:1;">🎹 SINTETIZADOR</button>
        <button class="preset-btn font-mono text-[9px]" id="mute-btn" style="flex:1;">✕ SILENCIO</button>
      </div>
    </div>

    <!-- Parameter Config -->
    <div class="control-group">
      <div class="section-title">⚡ CONFIGURACIÓN FÍSICA</div>
      
      <!-- Particles count -->
      <div class="slider-container">
        <div class="slider-header">
          <span>Partículas</span>
          <span class="slider-val" id="particles-val">${config.particlesCount}</span>
        </div>
        <input type="range" id="particles-input" min="300" max="3500" step="100" value="${config.particlesCount}">
      </div>

      <!-- BPM speed -->
      <div class="slider-container">
        <div class="slider-header">
          <span>Latido (BPM)</span>
          <span class="slider-val" id="bpm-val">${config.bpm} BPM</span>
        </div>
        <input type="range" id="bpm-input" min="30" max="140" step="1" value="${config.bpm}">
      </div>

      <!-- Particle Size -->
      <div class="slider-container">
        <div class="slider-header">
          <span>Tamaño</span>
          <span class="slider-val" id="size-val">${config.particleSize}px</span>
        </div>
        <input type="range" id="size-input" min="1" max="5" step="0.5" value="${config.particleSize}">
      </div>

      <!-- Repulsion Radius -->
      <div class="slider-container">
        <div class="slider-header">
          <span>Radio de Repulsión</span>
          <span class="slider-val" id="radius-val">${config.repulsionRadius}px</span>
        </div>
        <input type="range" id="radius-input" min="30" max="250" step="5" value="${config.repulsionRadius}">
      </div>
    </div>

    <!-- Toggles -->
    <div class="control-group">
      <div class="section-title">⚙ PARÁMETROS FINOS</div>
      
      <div class="checkbox-row">
        <span>Efecto de Estela (Fondo tenue)</span>
        <label class="switch">
          <input type="checkbox" id="trails-input" ${config.trailStrength < 0.99 ? 'checked' : ''}>
          <span class="toggle-slider"></span>
        </label>
      </div>

      <div class="checkbox-row">
        <span>Latido Doble Humano</span>
        <label class="switch">
          <input type="checkbox" id="doublebeat-input" ${config.enableDoubleBeat ? 'checked' : ''}>
          <span class="toggle-slider"></span>
        </label>
      </div>
    </div>

    <div class="panel-footer">
      <button class="footer-btn btn-primary" id="reset-btn">Restablecer Valores</button>
    </div>
  </div>

  <script>
    // Config values dynamically injected
    const presets = ${JSON.stringify(presets)};
    let activePreset = ${JSON.stringify(currentPreset)};
    
    let config = {
      particlesCount: ${config.particlesCount},
      bpm: ${config.bpm},
      colorScheme: "${config.colorScheme}",
      particleSize: ${config.particleSize},
      repulsionRadius: ${config.repulsionRadius},
      repulsionStrength: ${config.repulsionStrength},
      trailStrength: ${config.trailStrength},
      enableDoubleBeat: ${config.enableDoubleBeat},
      shimmerSpeed: 1,
      flowSpeed: 1,
      renderMode: "${config.renderMode || 'text'}",
      loveWords: "${config.loveWords || 'LOVE, YOU'}"
    };

    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    let particles = [];
    let mouse = { x: null, y: null, active: false };

    // Audio State properties
    let audioCtx = null;
    let synthIntervalId = null;
    let synthStep = 0;
    let htmlAudioElement = null;
    let activeMusicChannel = 'none'; // 'none' / 'synth' / 'mp3'

    // Function to parse hex to RGB
    function hexToRgb(hex) {
      const result = /^#?([a-f\\d]{2})([a-f\\d]{2})([a-f\\d]{2})$/i.exec(hex);
      return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } : { r: 255, g: 42, b: 95 };
    }

    function updateRootStyles() {
      const rgb = hexToRgb(activePreset.primary);
      document.documentElement.style.setProperty('--theme-color', activePreset.primary);
      document.documentElement.style.setProperty('--theme-color-rgb', \`\${rgb.r}, \${rgb.g}, \${rgb.b}\`);
    }

    // Mathematical heart parametric coordinates
    function getHeartPoint(t) {
      const x = 16 * Math.pow(Math.sin(t), 3);
      const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
      return { x, y };
    }

    // Initialize/Regenerate Particle arrays with filling
    function initializeParticles() {
      particles = [];
      const currentCount = config.particlesCount;
      const listWords = config.loveWords.split(',').map(w => w.trim().toUpperCase()).filter(w => w.length > 0);
      const safeWords = listWords.length > 0 ? listWords : ['LOVE', 'YOU'];

      for (let i = 0; i < currentCount; i++) {
        const t = Math.random() * Math.PI * 2;
        const basePoint = getHeartPoint(t);
        
        let tx, ty;
        let tag = 'shell';

        // 40% shell edge outlines, 60% solid mathematically complete inside filling!
        if (Math.random() < 0.40) {
          tag = 'shell';
          const spread = 0.5 + Math.random() * 1.5;
          const randomAngle = Math.random() * Math.PI * 2;
          tx = basePoint.x * 14.5 + Math.cos(randomAngle) * spread;
          ty = basePoint.y * 14.5 + Math.sin(randomAngle) * spread;
        } else {
          tag = 'core';
          const r = Math.pow(Math.random(), 1.3); // math fill formula
          const spread = Math.random() * 2.5;
          tx = basePoint.x * 14.5 * r + (Math.random() - 0.5) * spread;
          ty = basePoint.y * 14.5 * r + (Math.random() - 0.5) * spread;
        }

        particles.push({
          id: i,
          tx: tx,
          ty: ty,
          x: width / 2 + (Math.random() - 0.5) * width,
          y: height / 2 + (Math.random() - 0.5) * height,
          vx: (Math.random() - 0.5) * 4,
          vy: (Math.random() - 0.5) * 4,
          size: Math.max(0.6, config.particleSize * (Math.random() * 0.7 + 0.65) * (tag === 'shell' ? 1 : 0.8)),
          alpha: Math.random() * 0.65 + 0.35,
          phase: Math.random() * Math.PI * 2,
          speedOffset: Math.random() * 0.8 + 0.3,
          tag: tag,
          word: safeWords[i % safeWords.length]
        });
      }
    }

    // Web Audio Synthesizer Chord Player
    function initWebAudio() {
      if (audioCtx) return;
      try {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AudioContextClass();
      } catch (err) {
        console.warn("Audio Context init blocked:", err);
      }
    }

    function playSfx(freq, duration, type='sine') {
      if (!audioCtx) return;
      try {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + duration);
      } catch(e){}
    }

    function startSynthesizer() {
      initWebAudio();
      if (!audioCtx) return;
      
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }

      if (synthIntervalId) clearInterval(synthIntervalId);
      
      activeMusicChannel = 'synth';
      synthStep = 0;

      // Romantic chord transitions: Fmaj9 -> G6 -> Em7 -> Am7
      const chords = [
        [174.61, 261.63, 329.63, 349.23, 440.00], 
        [196.00, 293.66, 329.63, 392.00, 493.88], 
        [164.81, 246.94, 329.63, 392.00, 587.33], 
        [220.00, 261.63, 329.63, 440.00, 523.25]  
      ];

      synthIntervalId = setInterval(() => {
        const chordIdx = Math.floor(synthStep / 8) % chords.length;
        const noteIdx = synthStep % chords[chordIdx].length;
        const freq = chords[chordIdx][noteIdx];

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        const delay = audioCtx.createDelay();
        const delayGain = audioCtx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

        gain.gain.setValueAtTime(0, audioCtx.currentTime);
        gain.gain.linearRampToValueAtTime(0.12, audioCtx.currentTime + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.25);

        delay.delayTime.setValueAtTime(0.35, audioCtx.currentTime);
        delayGain.gain.setValueAtTime(0.20, audioCtx.currentTime);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        gain.connect(delay);
        delay.connect(delayGain);
        delayGain.connect(audioCtx.destination);
        delayGain.connect(delay);

        osc.start();
        osc.stop(audioCtx.currentTime + 1.35);

        synthStep++;
      }, 220);
    }

    function stopSynthesizer() {
      if (synthIntervalId) {
        clearInterval(synthIntervalId);
        synthIntervalId = null;
      }
    }

    function playMp3OrSynth() {
      initWebAudio();
      const audio = new Audio('/song.mp3');
      audio.crossOrigin = "anonymous";
      audio.loop = true;
      htmlAudioElement = audio;

      const onCanPlay = () => {
        activeMusicChannel = 'mp3';
        document.getElementById('mp3-lbl').textContent = '✅ REPRODUCIENDO: Canción de Amor 🎵';
        
        if (audioCtx) {
          if (audioCtx.state === 'suspended') {
            audioCtx.resume();
          }
          try {
            const source = audioCtx.createMediaElementSource(audio);
            source.connect(audioCtx.destination);
          } catch(e){}
        }
        audio.play().catch(e => console.log("Autoplay waiting gesture..."));
      };

      audio.addEventListener('canplaythrough', onCanPlay);

      audio.addEventListener('error', () => {
        // Fallback: If /song.mp3 failed, load the gorgeous Chopin audio from archive.org
        if (audio.src && audio.src.indexOf('/song.mp3') !== -1) {
          audio.src = 'https://archive.org/download/ChopinNocturneOp9No2/Chopin-NocturneOp9No2.mp3';
          audio.load();
        } else {
          startSynthesizer();
        }
      });

      audio.load();
    }

    // Calculate real heart beat scale based on lub-dub wave
    function getHeartBeatScale(timeMs, bpm) {
      const msPerBeat = (60 / bpm) * 1000;
      const progress = (timeMs % msPerBeat) / msPerBeat;

      if (!config.enableDoubleBeat) {
        return 1.0 + 0.10 * Math.sin(progress * Math.PI * 2);
      }

      // Human cardiac dual rhythm
      if (progress < 0.15) {
        const p = progress / 0.15;
        return 1.0 + 0.15 * Math.sin(p * Math.PI);
      } else if (progress < 0.25) {
        return 1.0;
      } else if (progress < 0.40) {
        const p = (progress - 0.25) / 0.15;
        return 1.0 + 0.08 * Math.sin(p * Math.PI);
      } else {
        return 1.0;
      }
    }

    let lastTime = 0;
    
    function animate(timeMs) {
      requestAnimationFrame(animate);
      
      const deltaTime = timeMs - lastTime;
      lastTime = timeMs;

      // Clear trails
      if (config.trailStrength < 0.99) {
        ctx.fillStyle = \`rgba(0, 0, 0, \${config.trailStrength})\`;
        ctx.fillRect(0, 0, width, height);
      } else {
        ctx.clearRect(0, 0, width, height);
      }

      const pulseScale = getHeartBeatScale(timeMs, config.bpm);
      const centerX = width / 2;
      const centerY = height / 2;

      const screenResponsiveScale = Math.min(width, height) / 440;

      // Styles
      const primaryColor = activePreset.primary;
      const secondaryColor = activePreset.secondary;
      const accentColor = activePreset.accent;

      // Loop particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        
        // Shimmering speed
        p.phase += 0.035 * p.speedOffset;
        const shimmer = Math.sin(p.phase);
        
        // Circular wave breeze flow
        const waveX = Math.sin(timeMs * 0.0012 + p.speedOffset) * 2;
        const waveY = Math.cos(timeMs * 0.0008 + p.speedOffset) * 2;

        // Coordinate scaling relative to central point
        const heartScale = screenResponsiveScale * pulseScale;
        const targetX = centerX + p.tx * heartScale + waveX;
        const targetY = centerY + p.ty * heartScale + waveY;

        // Force spring pull
        const dxToTarget = targetX - p.x;
        const dyToTarget = targetY - p.y;

        const springPower = p.tag === 'shell' ? 0.22 : 0.18;
        p.vx += dxToTarget * springPower;
        p.vy += dyToTarget * springPower;

        // Cursor repulsion
        if (mouse.active && mouse.x !== null && mouse.y !== null) {
          const dxMouse = p.x - mouse.x;
          const dyMouse = p.y - mouse.y;
          const distMouse = Math.sqrt(dxMouse * dxMouse + dyMouse * dyMouse);
          
          if (distMouse < config.repulsionRadius) {
            const push = (config.repulsionRadius - distMouse) / config.repulsionRadius;
            const pushStrength = push * config.repulsionStrength * 2.8;
            p.vx += (dxMouse / (distMouse || 1)) * pushStrength;
            p.vy += (dyMouse / (distMouse || 1)) * pushStrength;
          }
        }

        // Apply drag physics
        p.vx *= 0.78;
        p.vy *= 0.78;
        p.x += p.vx;
        p.y += p.vy;

        // Drawing render Modes
        const renderedAlpha = Math.max(0.12, Math.min(1.0, p.alpha * (0.75 + shimmer * 0.25)));
        ctx.globalAlpha = renderedAlpha;

        if (config.renderMode === 'text') {
          // Typography Love words particles
          const sizeLimit = Math.max(6, p.size * 3.8);
          ctx.font = \`\${p.tag === 'shell' ? 'bold' : 'normal'} \${sizeLimit}px sans-serif\`;
          ctx.fillStyle = p.tag === 'shell' 
            ? (shimmer > 0.5 ? accentColor : primaryColor)
            : secondaryColor;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(p.word || 'LOVE', p.x, p.y);
        } else if (config.renderMode === 'dots') {
          // Neon classic dots
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.tag === 'shell' ? primaryColor : secondaryColor;
          ctx.fill();
        } else {
          // Mixed hybridized styling
          if (p.id % 3 === 0) {
            const sizeLimit = Math.max(6, p.size * 3.6);
            ctx.font = \`bold \${sizeLimit}px sans-serif\`;
            ctx.fillStyle = primaryColor;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(p.word || 'YOU', p.x, p.y);
          } else {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * 0.8, 0, Math.PI * 2);
            ctx.fillStyle = secondaryColor;
            ctx.fill();
          }
        }
      }

      ctx.globalAlpha = 1.0;
    }

    // UI Configuration panel logic
    const panel = document.getElementById('panel');
    const toggleBtn = document.getElementById('toggle-btn');
    const presetsContainer = document.getElementById('presets-container');

    toggleBtn.addEventListener('click', () => {
      panel.classList.toggle('collapsed');
    });

    // Color presets populator
    function renderPresets() {
      presetsContainer.innerHTML = '';
      presets.forEach(preset => {
        const btn = document.createElement('button');
        btn.className = \`preset-btn \${preset.id === activePreset.id ? 'active' : ''}\`;
        btn.style.setProperty('--theme-color', preset.primary);
        btn.style.setProperty('--theme-color-rgb', hexToRgb(preset.primary));
        btn.innerHTML = \`
          <span class="color-dot" style="background: \${preset.primary}; box-shadow: 0 0 6px \${preset.primary}"></span>
          \${preset.name}
        \`;
        btn.addEventListener('click', () => {
          activePreset = preset;
          document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          updateRootStyles();
          initializeParticles();
        });
        presetsContainer.appendChild(btn);
      });
    }

    // Bind configuration inputs
    function bindInputs() {
      const pText = document.getElementById('words-text');
      pText.value = config.loveWords;
      pText.addEventListener('input', (e) => {
        config.loveWords = e.target.value;
        initializeParticles();
      });

      // Render Mode grids
      document.querySelectorAll('#rendermode-grid .radio-option').forEach(opt => {
        opt.addEventListener('click', () => {
          document.querySelectorAll('#rendermode-grid .radio-option').forEach(o => o.classList.remove('selected'));
          opt.classList.add('selected');
          config.renderMode = opt.getAttribute('data-val');
          
          const wrap = document.getElementById('words-wrap');
          if (config.renderMode === 'dots') {
            wrap.style.display = 'none';
          } else {
            wrap.style.display = 'block';
          }
        });
      });

      // Particles sliders
      const particlesInput = document.getElementById('particles-input');
      const particlesVal = document.getElementById('particles-val');
      particlesInput.addEventListener('input', (e) => {
        config.particlesCount = parseInt(e.target.value);
        particlesVal.textContent = config.particlesCount;
        initializeParticles();
      });

      const bpmInput = document.getElementById('bpm-input');
      const bpmVal = document.getElementById('bpm-val');
      const bpmlogs = document.getElementById('bpmlogs');
      bpmInput.addEventListener('input', (e) => {
        config.bpm = parseInt(e.target.value);
        bpmVal.textContent = \`\${config.bpm} BPM\`;
        bpmlogs.textContent = \`RITMO CARDIÁCO COMPLETO: \${config.bpm} BPM\`;
      });

      const sizeInput = document.getElementById('size-input');
      const sizeVal = document.getElementById('size-val');
      sizeInput.addEventListener('input', (e) => {
        config.particleSize = parseFloat(e.target.value);
        sizeVal.textContent = \`\${config.particleSize}px\`;
        particles.forEach(p => {
          p.size = Math.max(0.6, config.particleSize * (Math.random() * 0.7 + 0.65) * (p.tag === 'shell' ? 1 : 0.8));
        });
      });

      const radiusInput = document.getElementById('radius-input');
      const radiusVal = document.getElementById('radius-val');
      radiusInput.addEventListener('input', (e) => {
        config.repulsionRadius = parseInt(e.target.value);
        radiusVal.textContent = \`\${config.repulsionRadius}px\`;
      });

      const trailsInput = document.getElementById('trails-input');
      trailsInput.addEventListener('change', (e) => {
        config.trailStrength = e.target.checked ? 0.12 : 1.0;
      });

      const doublebeatInput = document.getElementById('doublebeat-input');
      doublebeatInput.addEventListener('change', (e) => {
        config.enableDoubleBeat = e.target.checked;
      });

      // Sound Buttons
      document.getElementById('synth-btn').addEventListener('click', () => {
        if (htmlAudioElement) htmlAudioElement.pause();
        startSynthesizer();
      });

      document.getElementById('mute-btn').addEventListener('click', () => {
        stopSynthesizer();
        if (htmlAudioElement) htmlAudioElement.pause();
        activeMusicChannel = 'none';
      });

      // File MP3 Uploader local Client
      document.getElementById('mp3-uploader').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        stopSynthesizer();
        if (htmlAudioElement) htmlAudioElement.pause();

        document.getElementById('mp3-lbl').textContent = '✅ SUBIDO: ' + file.name.substring(0, 16) + '...';
        
        const fileUrl = URL.createObjectURL(file);
        htmlAudioElement = new Audio(fileUrl);
        htmlAudioElement.loop = true;
        
        initWebAudio();
        activeMusicChannel = 'mp3';
        
        htmlAudioElement.play().catch(err => {
          console.warn("La autoplay policy requiere interacción para sonar.");
        });
      });

      // Reset Button
      const resetBtn = document.getElementById('reset-btn');
      resetBtn.addEventListener('click', () => {
        config = {
          particlesCount: 2200,
          bpm: 65,
          colorScheme: 'neon-rose',
          particleSize: 2.3,
          repulsionRadius: 120,
          repulsionStrength: 10,
          trailStrength: 0.12,
          enableDoubleBeat: true,
          renderMode: 'text',
          loveWords: 'LOVE, YOU'
        };
        
        activePreset = presets[0];
        pText.value = config.loveWords;
        
        particlesInput.value = config.particlesCount;
        particlesVal.textContent = config.particlesCount;

        bpmInput.value = config.bpm;
        bpmVal.textContent = \`\${config.bpm} BPM\`;
        bpmlogs.textContent = \`RITMO CARDIÁCO COMPLETO: \${config.bpm} BPM\`;

        sizeInput.value = config.particleSize;
        sizeVal.textContent = \`\${config.particleSize}px\`;

        radiusInput.value = config.repulsionRadius;
        radiusVal.textContent = \`\${config.repulsionRadius}px\`;

        trailsInput.checked = true;
        doublebeatInput.checked = true;

        document.querySelectorAll('#rendermode-grid .radio-option').forEach(o => {
          o.classList.remove('selected');
          if (o.getAttribute('data-val') === 'text') o.classList.add('selected');
        });
        document.getElementById('words-wrap').style.display = 'block';

        renderPresets();
        updateRootStyles();
        initializeParticles();
      });
    }

    // Decryption lock triggering
    const unlockTrigger = document.getElementById('unlock-trigger');
    const decryptScreen = document.getElementById('decrypt-screen');
    const scrambleEl = document.getElementById('scramble-el');
    const progressWrapper = document.getElementById('progress-wrapper');
    const progressBar = document.getElementById('progress-bar');
    const progressTxt = document.getElementById('progress-txt');

    let decryptionProgress = 0;
    let scrambleInterval = null;

    // Scramble effect during load
    const originalText = "DESCIFRANDO_CODIGO_CARDIACO";
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*()_+{}[]|";
    scrambleInterval = setInterval(() => {
      let display = "";
      for(let i=0; i<originalText.length; i++) {
        if (Math.random() < 0.15) {
          display += chars[Math.floor(Math.random() * chars.length)];
        } else {
          display += originalText[i];
        }
      }
      scrambleEl.textContent = display;
    }, 100);

    unlockTrigger.addEventListener('click', () => {
      unlockTrigger.style.display = 'none';
      progressWrapper.style.display = 'block';
      initWebAudio();
      playSfx(440, 0.15, 'sine');

      const interval = setInterval(() => {
        decryptionProgress += 2;
        progressBar.style.width = decryptionProgress + '%';
        progressTxt.textContent = decryptionProgress + '%';

        if (decryptionProgress % 10 === 0) {
          playSfx(600 + decryptionProgress * 5, 0.04, 'sine');
        }

        if (decryptionProgress >= 100) {
          clearInterval(interval);
          clearInterval(scrambleInterval);
          scrambleEl.textContent = "¡MENSAJE DESCIFRADO!";
          playSfx(880, 0.3, 'triangle');
          
          setTimeout(() => {
            decryptScreen.style.opacity = '0';
            decryptScreen.style.transform = 'scale(1.1)';
            setTimeout(() => {
              decryptScreen.style.display = 'none';
            }, 600);
            
             // Auto start romantic MP3 music with automatic classical piano fallback or synthesizer
             playMp3OrSynth();
          }, 450);
        }
      }, 40);
    });

    // Pointer events binding
    window.addEventListener('mousemove', (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.active = true;
    });

    window.addEventListener('mouseleave', () => {
      mouse.x = null;
      mouse.y = null;
      mouse.active = false;
    });

    // Touch support
    window.addEventListener('touchstart', (e) => {
      if (e.touches.length > 0) {
        mouse.x = e.touches[0].clientX;
        mouse.y = e.touches[0].clientY;
        mouse.active = true;
        initWebAudio();
      }
    });

    window.addEventListener('touchmove', (e) => {
      if (e.touches.length > 0) {
        mouse.x = e.touches[0].clientX;
        mouse.y = e.touches[0].clientY;
        mouse.active = true;
      }
    });

    window.addEventListener('touchend', () => {
      mouse.x = null;
      mouse.y = null;
      mouse.active = false;
    });

    window.addEventListener('click', () => {
      initWebAudio();
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      playSfx(180, 0.08, 'sine'); // tactile click heartbeat thump
    });

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initializeParticles();
    });

    // Initial setup
    updateRootStyles();
    renderPresets();
    bindInputs();
    initializeParticles();
    animate(0);

  </script>
</body>
</html>`;
}
