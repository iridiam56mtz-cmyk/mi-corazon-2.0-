/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ColorScheme } from '../types';

export const COLOR_PRESETS: ColorScheme[] = [
  {
    id: 'neon-rose',
    name: 'Rosa Neón',
    primary: '#ff2a5f',
    secondary: '#ff758c',
    accent: '#ffffff',
    shadow: 'rgba(255, 42, 95, 0.65)'
  },
  {
    id: 'velvet-red',
    name: 'Rojo Carmesí',
    primary: '#e60026',
    secondary: '#ff4d6d',
    accent: '#ffb3c1',
    shadow: 'rgba(230, 0, 38, 0.7)'
  },
  {
    id: 'electric-magenta',
    name: 'Fucsia Eléctrico',
    primary: '#ff007f',
    secondary: '#ea00d9',
    accent: '#ffffff',
    shadow: 'rgba(255, 0, 127, 0.65)'
  },
  {
    id: 'cyber-violet',
    name: 'Violeta Cíber',
    primary: '#9b51e0',
    secondary: '#bf55ec',
    accent: '#e0b0ff',
    shadow: 'rgba(155, 81, 224, 0.7)'
  },
  {
    id: 'cyan-ice',
    name: 'Cian Glacial',
    primary: '#00f2fe',
    secondary: '#4facfe',
    accent: '#ffffff',
    shadow: 'rgba(0, 242, 254, 0.7)'
  },
  {
    id: 'amber-fire',
    name: 'Ámbar Volcánico',
    primary: '#ff5500',
    secondary: '#ffaa00',
    accent: '#ffe17d',
    shadow: 'rgba(255, 85, 0, 0.65)'
  },
  {
    id: 'emerald-aurora',
    name: 'Verde Aurora',
    primary: '#00ff87',
    secondary: '#60efff',
    accent: '#ffffff',
    shadow: 'rgba(0, 255, 135, 0.65)'
  }
];
